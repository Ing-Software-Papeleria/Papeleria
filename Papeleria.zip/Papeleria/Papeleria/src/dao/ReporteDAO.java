package dao;
/**
 *
 * @author adair
 */
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;

public class ReporteDAO {

    public static double obtenerVentasDelMes() {
        String sql = """
            SELECT COALESCE(SUM(total), 0) AS total_ventas
            FROM ventas
            WHERE EXTRACT(MONTH FROM fecha) = EXTRACT(MONTH FROM CURRENT_DATE)
            AND EXTRACT(YEAR FROM fecha) = EXTRACT(YEAR FROM CURRENT_DATE)
        """;
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble("total_ventas");
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public static int obtenerProductosVendidos() {
        String sql = """
            SELECT COALESCE(SUM(dv.cantidad), 0) AS total_productos
            FROM detalle_ventaS dv
            JOIN ventas v ON dv.id_venta = v.id_venta
            WHERE EXTRACT(MONTH FROM v.fecha) = EXTRACT(MONTH FROM CURRENT_DATE)
            AND EXTRACT(YEAR FROM v.fecha) = EXTRACT(YEAR FROM CURRENT_DATE)
        """;
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("total_productos");
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public static int obtenerClientesNuevos() {
    String sql = """
            SELECT COUNT(*) AS nuevos_clientes
            FROM (
                SELECT v.id_cliente, MIN(v.fecha) AS primera_venta
                FROM ventas v
                GROUP BY v.id_cliente
                HAVING EXTRACT(MONTH FROM MIN(v.fecha)) = EXTRACT(MONTH FROM CURRENT_DATE)
                   AND EXTRACT(YEAR FROM MIN(v.fecha)) = EXTRACT(YEAR FROM CURRENT_DATE)
            ) AS subquery
        """;

        try (Connection conn = Conexion.getConexion();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("nuevos_clientes");
        }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int obtenerStockFinal() {
        int stockFinal = 0;
        String sql = "SELECT SUM(stock_actual) AS stock_final FROM productos";
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                stockFinal = rs.getInt("stock_final");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stockFinal;
    }

    public int obtenerStockInicial() {
        int stockInicial = 0;
        // FORMULA: (Stock Total Actual) - (Lo que entró hoy) + (Lo que salió hoy)
        String sql = "SELECT " +
                     "(SELECT COALESCE(SUM(stock_actual), 0) FROM productos) - " +
                     "(SELECT COALESCE(SUM(cantidad), 0) FROM almacen_movimientos WHERE tipo_movimiento = 'entrada' AND DATE(fecha) = CURRENT_DATE) + " +
                     "(SELECT COALESCE(SUM(cantidad), 0) FROM almacen_movimientos WHERE tipo_movimiento = 'salida' AND DATE(fecha) = CURRENT_DATE)";

        try (java.sql.Connection conn = util.Conexion.getConexion();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                stockInicial = rs.getInt(1);
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        return stockInicial;
    }
    public List<Object[]> obtenerTopProductos() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT p.nombre, SUM(dv.cantidad) as cantidad_total, SUM(dv.cantidad * dv.precio_unitario) as dinero_generado " +
                     "FROM detalle_ventas dv " +
                     "INNER JOIN productos p ON dv.id_producto = p.id_producto " +
                     "GROUP BY p.nombre " +
                     "ORDER BY cantidad_total DESC " +
                     "LIMIT 5";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getString("nombre"),
                    rs.getInt("cantidad_total"),
                    rs.getDouble("dinero_generado")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // 2. REPORTE: Valor del Inventario (Dinero invertido)
    public double obtenerValorInventario() {
        String sql = "SELECT SUM(precio * stock_actual) as total FROM productos";
        double total = 0;
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                total = rs.getDouble("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return total;
    }
    public static double obtenerVentasDeHoy() {
        String sql = "SELECT COALESCE(SUM(total), 0) FROM ventas WHERE DATE(fecha) = CURRENT_DATE";
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0.0;
    }
    public int obtenerTotalProductosVendidosHoy() {
        String sql = "SELECT COALESCE(SUM(dv.cantidad), 0) " +
                     "FROM detalle_ventas dv " +
                     "JOIN ventas v ON dv.id_venta = v.id_venta " +
                     "WHERE DATE(v.fecha) = CURRENT_DATE";

        try (java.sql.Connection conn = util.Conexion.getConexion();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (java.sql.SQLException e) { 
            e.printStackTrace(); 
        }
        return 0;
    }
}


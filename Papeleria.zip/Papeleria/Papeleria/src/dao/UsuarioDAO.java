package dao;

import java.sql.*;
import modelo.Roles;
import modelo.Usuarios;
import util.Conexion;

public class UsuarioDAO {

    public Usuarios obtenerPorCodigo(String codigo) {
        Usuarios usuario = null;
        String sql = "SELECT * FROM usuarios WHERE codigo_usuario = ?";
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {            
            ps.setString(1, codigo);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                usuario = new Usuarios();
                usuario.setIdUsuario(rs.getInt("id_usuario"));
                usuario.setCodigoUsuario(rs.getString("codigo_usuario"));
                usuario.setContrasena(rs.getString("contrasena"));
                Roles rol = new Roles();
                rol.setIdRol(rs.getInt("id_rol"));
                usuario.setIdRol(rol);
                usuario.setNombreUsuario(rs.getString("nombre_usuario"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuario;
    }
}



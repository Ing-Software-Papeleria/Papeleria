package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.Conexion;

public class ReporteAlmacenDAO {

    // Productos recibidos hoy (productos distintos con entrada)
    public static int obtenerProductosRecibidosHoy() {
        String sql = """
            SELECT COUNT(DISTINCT id_producto) AS total
            FROM almacen_movimientos
            WHERE tipo_movimiento = 'entrada'
              AND DATE(fecha) = CURRENT_DATE
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Stock total agregado hoy
    public static int obtenerStockAgregadoHoy() {
        String sql = """
            SELECT COALESCE(SUM(cantidad), 0) AS total
            FROM almacen_movimientos
            WHERE tipo_movimiento = 'entrada'
              AND DATE(fecha) = CURRENT_DATE
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Stock retirado hoy
    public static int obtenerStockRetiradoHoy() {
        String sql = """
            SELECT COALESCE(SUM(cantidad), 0) AS total
            FROM almacen_movimientos
            WHERE tipo_movimiento = 'salida'
              AND DATE(fecha) = CURRENT_DATE
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}

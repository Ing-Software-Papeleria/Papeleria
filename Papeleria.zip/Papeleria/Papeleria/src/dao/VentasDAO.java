package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Clientes;
import modelo.Ventas;
import java.math.BigDecimal;
import util.Conexion;

public class VentasDAO {
    
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion cn = new Conexion();
    
    public List<Object[]> obtenerVentas() {
        List<Object[]> listapr = new ArrayList<>();
        String sql = """
                    SELECT 
                        V.id_venta, 
                        V.fecha, 
                        V.id_cliente,
                        c.nombre,
                        V.total, 
                        V.estado 
                    FROM ventas v
                    JOIN clientes c ON v.id_cliente=c.id_cliente 
                    """;

        try (Connection conn = Conexion.getConexion();
     PreparedStatement ps = conn.prepareStatement(sql);
     ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
        // Crear el objeto cliente
        Clientes cliente = new Clientes();
        cliente.setNombre(rs.getString("nombre")); 

        // Agregar los datos a la lista
        listapr.add(new Object[]{
            rs.getInt("id_venta"),
            rs.getDate("fecha"),
            cliente.getNombre(), 
            rs.getBigDecimal("total"),
            rs.getString("estado")
        });
        }
        } catch (SQLException e) {
            e.printStackTrace();
            }
        return listapr;
    }
    public List<Object[]> obtenerVentasRecientes() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT 
                id_venta, fecha, total
            FROM ventas
            ORDER BY fecha DESC
            LIMIT 10
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getInt("id_venta"),
                    rs.getTimestamp("fecha"),
                    rs.getBigDecimal("total")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public List<Object[]> obtenerProductosMasVendidos() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT 
                p.nombre AS producto,
                SUM(dv.cantidad) AS total_vendido
            FROM detalle_ventas dv
            JOIN productos p ON dv.id_producto = p.id_producto
            GROUP BY p.nombre
            ORDER BY total_vendido DESC
            LIMIT 10
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getString("producto"),
                    rs.getInt("total_vendido")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
    public List<Object[]> obtenerVentasDeHoy() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT 
                v.id_venta,
                v.fecha,
                c.nombre AS cliente,
                v.total,
                v.estado
            FROM ventas v
            JOIN clientes c ON v.id_cliente = c.id_cliente
            WHERE DATE(v.fecha) = CURRENT_DATE
            ORDER BY v.fecha DESC
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getInt("id_venta"),
                    rs.getTimestamp("fecha"),
                    rs.getString("cliente"),
                    rs.getBigDecimal("total"),
                    rs.getString("estado")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public int registrarVenta(int idCliente, BigDecimal total, String estado) {

        String sql = """
            INSERT INTO ventas (id_cliente, total, estado)
            VALUES (?, ?, ?)
            RETURNING id_venta
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            ps.setBigDecimal(2, total);
            ps.setString(3, estado);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_venta");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}

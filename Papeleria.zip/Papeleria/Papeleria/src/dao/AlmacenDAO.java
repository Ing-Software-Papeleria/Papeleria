package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.AlmacenMovimientos;
import util.Conexion;

/**
 *
 * @author yisus
 */
public class AlmacenDAO {
    public List<Object[]> obtenerMovimientosHoy() {
        List<Object[]> lista = new ArrayList<>();
        String sql = """
            SELECT 
                to_char(a.fecha, 'HH24:MI') AS hora,
                p.nombre AS producto,
                a.tipo_movimiento,
                a.cantidad,
                p.stock_actual,
                u.nombre_usuario AS usuario
            FROM almacen_movimientos a
            JOIN productos p ON a.id_producto = p.id_producto
            JOIN usuarios u ON a.id_usuario = u.id_usuario
            WHERE a.fecha::date = CURRENT_DATE
            ORDER BY a.fecha ASC
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getString("hora"),
                    rs.getString("producto"),
                    rs.getString("tipo_movimiento"),
                    rs.getInt("cantidad"),
                    rs.getInt("stock_actual"),
                    rs.getString("usuario")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
    
    // Papeleria/src/dao/AlmacenDAO.java

public boolean registrarMovimiento(int idProducto, String tipo, int cantidad, int idUsuario) {
        Connection con = null;
        PreparedStatement ps = null;

        // Consulta 1: Insertar el movimiento en la bitácora
        String sqlMov = "INSERT INTO almacen_movimientos (id_producto, tipo_movimiento, cantidad, id_usuario, fecha) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";

        // Consulta 2: Actualizar el stock en la tabla productos
        // Si es entrada SUMA, si es salida RESTA
        String sqlUpdate = "";
        if (tipo.equals("entrada")) {
            sqlUpdate = "UPDATE productos SET stock_actual = stock_actual + ? WHERE id_producto = ?";
        } else {
            sqlUpdate = "UPDATE productos SET stock_actual = stock_actual - ? WHERE id_producto = ?";
        }

        try {
            con = Conexion.getConexion();
            con.setAutoCommit(false); // Transacción: o se hacen las dos o ninguna

            // 1. Insertar Movimiento
            ps = con.prepareStatement(sqlMov);
            ps.setInt(1, idProducto);
            ps.setString(2, tipo);
            ps.setInt(3, cantidad);
            ps.setInt(4, idUsuario);
            ps.executeUpdate();
            ps.close();

            // 2. Actualizar Producto
            ps = con.prepareStatement(sqlUpdate);
            ps.setInt(1, cantidad);
            ps.setInt(2, idProducto);
            ps.executeUpdate();

            con.commit(); // Confirmar cambios
            return true;

        } catch (SQLException e) {
            System.err.println("Error en transacción de almacén: " + e.getMessage());
            try { if(con!=null) con.rollback(); } catch(SQLException ex){} // Deshacer si falla
            return false;
        } finally {
            try { if(ps!=null) ps.close(); if(con!=null) con.close(); } catch(SQLException e){}
        }
    }
}

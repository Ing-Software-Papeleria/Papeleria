/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author adair
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Clientes;
import util.Conexion;

public class ClientesDAO {
    
    public List<Object[]> obtenerClientes() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT id_cliente, nombre, telefono, email
            FROM clientes
            ORDER BY nombre
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("email")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    // --------------------------------------
    // 2. CLIENTES ACTIVOS (CON AL MENOS UNA VENTA)
    // --------------------------------------
    public List<Object[]> obtenerClientesActivos() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT DISTINCT 
                c.id_cliente,
                c.nombre,
                c.telefono,
                c.email
            FROM clientes c
            JOIN ventas v ON v.id_cliente = c.id_cliente
            ORDER BY c.nombre
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("email")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
    public Clientes buscarCliente(int idCliente) {
        String sql = "SELECT * FROM clientes WHERE id_cliente = ?";
        Clientes c = null;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCliente);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    c = new Clientes();
                    c.setIdCliente(rs.getInt("id_cliente"));
                    c.setNombre(rs.getString("nombre"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setEmail(rs.getString("email"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return c;
    }
    public int registrarCliente(Clientes cliente) {
        int idGenerado = -1;

        String sql = "INSERT INTO clientes (nombre, telefono, email) VALUES (?, ?, ?)";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getTelefono());
            ps.setString(3, cliente.getEmail());

            int filas = ps.executeUpdate();
            if (filas > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    idGenerado = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al registrar cliente: " + e.getMessage());
        }
        return idGenerado;
    }
}

package dao;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Productos;
import modelo.Proveedores;
import util.Conexion;

public class ProductoDAO {
    
    
    public List<Object[]> obtenerProductos() {
        List<Object[]> lista = new ArrayList<>();
        String sql = """
                     SELECT p.nombre AS producto, p.categoria, p.precio, p.stock_actual, p.stock_minimo, pr.nombre 
                     FROM productos p
                     JOIN proveedores pr ON p.id_proveedor=pr.id_proveedor
                     """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Proveedores prov = new Proveedores();
                prov.setNombre(rs.getString("nombre"));
                
                lista.add(new Object[]{
                rs.getString("producto"),
                rs.getString("categoria"),
                rs.getBigDecimal("precio"),
                rs.getInt("stock_actual"),
                rs.getInt("stock_minimo"),   
                prov.getNombre()
                });
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener productos: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }
    
    public List<Object[]> obtenerProductosConStockBajo() {
    List<Object[]> lista = new ArrayList<>();

    String sql = """
        SELECT 
            p.nombre AS producto,
            p.stock_actual,
            p.stock_minimo,
            pr.nombre AS proveedor
        FROM productos p
        JOIN proveedores pr ON p.id_proveedor = pr.id_proveedor
        WHERE p.stock_actual <= p.stock_minimo
    """;

    try (Connection conn = Conexion.getConexion();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            lista.add(new Object[]{
                rs.getString("producto"),
                rs.getInt("stock_actual"),
                rs.getInt("stock_minimo"),
                rs.getString("proveedor")
            });
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
    }
    
    public int obtenerProveedorAleatorio() {
        String sql = "SELECT id_proveedor FROM proveedores ORDER BY RANDOM() LIMIT 1";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("id_proveedor");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; 
    }
    
    public int insertarProducto(String nombre, String categoria,BigDecimal precio, int stock, int stockMinimo) {
        String sql = "INSERT INTO productos (nombre, categoria, precio, stock_actual, stock_minimo, id_proveedor) "
                   + "VALUES (?, ?, ?, ?, ?, ?) RETURNING id_producto";
        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            int idProveedor = obtenerProveedorAleatorio();
            if (idProveedor == -1) {
                return -1;
            }

            ps.setString(1, nombre);
            ps.setString(2, categoria);
            ps.setBigDecimal(3, precio);
            ps.setInt(4, stock);
            ps.setInt(5, stockMinimo);
            ps.setInt(6, idProveedor);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id_producto");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }
    public List<Object[]> buscarProducto(String texto) {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT p.nombre, p.categoria, p.precio, p.stock_actual, p.stock_minimo, pr.nombre " +
                     "FROM productos p " +
                     "INNER JOIN proveedores pr ON p.id_proveedor = pr.id_proveedor " +
                     "WHERE p.nombre ILIKE ? OR p.categoria ILIKE ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Los signos % permiten buscar texto en cualquier parte de la palabra
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Object[] fila = new Object[6];
                    fila[0] = rs.getString(1); // nombre
                    fila[1] = rs.getString(2); // categoria
                    fila[2] = rs.getDouble(3); // precio
                    fila[3] = rs.getInt(4);    // stock_actual (CORREGIDO según tu esquema)
                    fila[4] = rs.getInt(5);    // stock_minimo
                    fila[5] = rs.getString(6); // nombre proveedor
                    lista.add(fila);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    public Productos buscarProductoPorId(int id) {
        Productos prod = null;
        String sql = "SELECT * FROM productos WHERE id_producto = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    prod = new Productos();
                    prod.setIdProducto(rs.getInt("id_producto"));
                    prod.setNombre(rs.getString("nombre"));
                    prod.setCategoria(rs.getString("categoria"));
                    prod.setPrecio(rs.getBigDecimal("precio"));
                    prod.setStockActual(rs.getInt("stock_actual")); // Asegúrate que tu columna se llame así
                    prod.setStockMinimo(rs.getInt("stock_minimo"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prod;
    }

    // Actualizar stock restando la cantidad vendida
    public void actualizarStock(int idProducto, int cantidadVendida) {
        String sql = "UPDATE productos SET stock_actual = stock_actual - ? WHERE id_producto = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, cantidadVendida);
            ps.setInt(2, idProducto);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<Object[]> obtenerProductosMasVendidos() {
        List<Object[]> lista = new ArrayList<>();

        String sql = """
            SELECT 
                p.nombre AS producto,
                SUM(dv.cantidad) AS total_vendido,
                SUM(dv.cantidad * dv.precio_unitario) AS ingresos
            FROM detalle_ventas dv
            JOIN productos p ON dv.id_producto = p.id_producto
            GROUP BY p.nombre
            ORDER BY total_vendido DESC
            LIMIT 10;
        """;

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getString("producto"),
                    rs.getInt("total_vendido"),
                    rs.getBigDecimal("ingresos")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}
package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;
import modelo.Proveedores;
/**
 *
 * @author yisus
 */
public class ProveedorDAO {
    public List<Proveedores> obtenerProveedores() {
        List<Proveedores> listapr = new ArrayList<>();
        String sql = "SELECT nombre, telefono, email FROM proveedores";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Proveedores p = new Proveedores();
                p.setNombre(rs.getString("nombre"));
                p.setTelefono(rs.getString("telefono"));
                p.setEmail(rs.getString("email"));
                listapr.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener productos: " + e.getMessage());
            e.printStackTrace();
        }
        return listapr;
    }
    public boolean insertarProveedor(String nombre, String telefono, String email) {
        String sql = "INSERT INTO proveedores (nombre, telefono, email) VALUES (?, ?, ?)";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, telefono);
            ps.setString(3, email);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar proveedor: " + e.getMessage());
            return false;
        }
    }
    public List<modelo.Proveedores> buscarProveedores(String texto) {
        List<modelo.Proveedores> lista = new ArrayList<>();
        // Buscamos coincidencia en nombre, teléfono o email
        String sql = "SELECT * FROM proveedores WHERE nombre ILIKE ? OR telefono ILIKE ? OR email ILIKE ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            ps.setString(3, "%" + texto + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    modelo.Proveedores p = new modelo.Proveedores();
                    p.setIdProveedor(rs.getInt("id_proveedor"));
                    p.setNombre(rs.getString("nombre"));
                    p.setTelefono(rs.getString("telefono"));
                    p.setEmail(rs.getString("email"));
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar proveedores: " + e.getMessage());
        }
        return lista;
    }
}

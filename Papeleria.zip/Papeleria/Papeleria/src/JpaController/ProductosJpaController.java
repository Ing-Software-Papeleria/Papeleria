/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaController;

import JpaController.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Proveedores;
import modelo.AlmacenMovimientos;
import java.util.ArrayList;
import java.util.List;
import modelo.DetalleVentas;
import modelo.DetalleCompras;
import modelo.Productos;

/**
 *
 * @author yisus
 */
public class ProductosJpaController implements Serializable {

    public ProductosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Productos productos) {
        if (productos.getAlmacenMovimientosList() == null) {
            productos.setAlmacenMovimientosList(new ArrayList<AlmacenMovimientos>());
        }
        if (productos.getDetalleVentasList() == null) {
            productos.setDetalleVentasList(new ArrayList<DetalleVentas>());
        }
        if (productos.getDetalleComprasList() == null) {
            productos.setDetalleComprasList(new ArrayList<DetalleCompras>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Proveedores idProveedor = productos.getIdProveedor();
            if (idProveedor != null) {
                idProveedor = em.getReference(idProveedor.getClass(), idProveedor.getIdProveedor());
                productos.setIdProveedor(idProveedor);
            }
            List<AlmacenMovimientos> attachedAlmacenMovimientosList = new ArrayList<AlmacenMovimientos>();
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientosToAttach : productos.getAlmacenMovimientosList()) {
                almacenMovimientosListAlmacenMovimientosToAttach = em.getReference(almacenMovimientosListAlmacenMovimientosToAttach.getClass(), almacenMovimientosListAlmacenMovimientosToAttach.getIdMovimiento());
                attachedAlmacenMovimientosList.add(almacenMovimientosListAlmacenMovimientosToAttach);
            }
            productos.setAlmacenMovimientosList(attachedAlmacenMovimientosList);
            List<DetalleVentas> attachedDetalleVentasList = new ArrayList<DetalleVentas>();
            for (DetalleVentas detalleVentasListDetalleVentasToAttach : productos.getDetalleVentasList()) {
                detalleVentasListDetalleVentasToAttach = em.getReference(detalleVentasListDetalleVentasToAttach.getClass(), detalleVentasListDetalleVentasToAttach.getIdDetalle());
                attachedDetalleVentasList.add(detalleVentasListDetalleVentasToAttach);
            }
            productos.setDetalleVentasList(attachedDetalleVentasList);
            List<DetalleCompras> attachedDetalleComprasList = new ArrayList<DetalleCompras>();
            for (DetalleCompras detalleComprasListDetalleComprasToAttach : productos.getDetalleComprasList()) {
                detalleComprasListDetalleComprasToAttach = em.getReference(detalleComprasListDetalleComprasToAttach.getClass(), detalleComprasListDetalleComprasToAttach.getIdDetalle());
                attachedDetalleComprasList.add(detalleComprasListDetalleComprasToAttach);
            }
            productos.setDetalleComprasList(attachedDetalleComprasList);
            em.persist(productos);
            if (idProveedor != null) {
                idProveedor.getProductosList().add(productos);
                idProveedor = em.merge(idProveedor);
            }
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientos : productos.getAlmacenMovimientosList()) {
                Productos oldIdProductoOfAlmacenMovimientosListAlmacenMovimientos = almacenMovimientosListAlmacenMovimientos.getIdProducto();
                almacenMovimientosListAlmacenMovimientos.setIdProducto(productos);
                almacenMovimientosListAlmacenMovimientos = em.merge(almacenMovimientosListAlmacenMovimientos);
                if (oldIdProductoOfAlmacenMovimientosListAlmacenMovimientos != null) {
                    oldIdProductoOfAlmacenMovimientosListAlmacenMovimientos.getAlmacenMovimientosList().remove(almacenMovimientosListAlmacenMovimientos);
                    oldIdProductoOfAlmacenMovimientosListAlmacenMovimientos = em.merge(oldIdProductoOfAlmacenMovimientosListAlmacenMovimientos);
                }
            }
            for (DetalleVentas detalleVentasListDetalleVentas : productos.getDetalleVentasList()) {
                Productos oldIdProductoOfDetalleVentasListDetalleVentas = detalleVentasListDetalleVentas.getIdProducto();
                detalleVentasListDetalleVentas.setIdProducto(productos);
                detalleVentasListDetalleVentas = em.merge(detalleVentasListDetalleVentas);
                if (oldIdProductoOfDetalleVentasListDetalleVentas != null) {
                    oldIdProductoOfDetalleVentasListDetalleVentas.getDetalleVentasList().remove(detalleVentasListDetalleVentas);
                    oldIdProductoOfDetalleVentasListDetalleVentas = em.merge(oldIdProductoOfDetalleVentasListDetalleVentas);
                }
            }
            for (DetalleCompras detalleComprasListDetalleCompras : productos.getDetalleComprasList()) {
                Productos oldIdProductoOfDetalleComprasListDetalleCompras = detalleComprasListDetalleCompras.getIdProducto();
                detalleComprasListDetalleCompras.setIdProducto(productos);
                detalleComprasListDetalleCompras = em.merge(detalleComprasListDetalleCompras);
                if (oldIdProductoOfDetalleComprasListDetalleCompras != null) {
                    oldIdProductoOfDetalleComprasListDetalleCompras.getDetalleComprasList().remove(detalleComprasListDetalleCompras);
                    oldIdProductoOfDetalleComprasListDetalleCompras = em.merge(oldIdProductoOfDetalleComprasListDetalleCompras);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Productos productos) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Productos persistentProductos = em.find(Productos.class, productos.getIdProducto());
            Proveedores idProveedorOld = persistentProductos.getIdProveedor();
            Proveedores idProveedorNew = productos.getIdProveedor();
            List<AlmacenMovimientos> almacenMovimientosListOld = persistentProductos.getAlmacenMovimientosList();
            List<AlmacenMovimientos> almacenMovimientosListNew = productos.getAlmacenMovimientosList();
            List<DetalleVentas> detalleVentasListOld = persistentProductos.getDetalleVentasList();
            List<DetalleVentas> detalleVentasListNew = productos.getDetalleVentasList();
            List<DetalleCompras> detalleComprasListOld = persistentProductos.getDetalleComprasList();
            List<DetalleCompras> detalleComprasListNew = productos.getDetalleComprasList();
            if (idProveedorNew != null) {
                idProveedorNew = em.getReference(idProveedorNew.getClass(), idProveedorNew.getIdProveedor());
                productos.setIdProveedor(idProveedorNew);
            }
            List<AlmacenMovimientos> attachedAlmacenMovimientosListNew = new ArrayList<AlmacenMovimientos>();
            for (AlmacenMovimientos almacenMovimientosListNewAlmacenMovimientosToAttach : almacenMovimientosListNew) {
                almacenMovimientosListNewAlmacenMovimientosToAttach = em.getReference(almacenMovimientosListNewAlmacenMovimientosToAttach.getClass(), almacenMovimientosListNewAlmacenMovimientosToAttach.getIdMovimiento());
                attachedAlmacenMovimientosListNew.add(almacenMovimientosListNewAlmacenMovimientosToAttach);
            }
            almacenMovimientosListNew = attachedAlmacenMovimientosListNew;
            productos.setAlmacenMovimientosList(almacenMovimientosListNew);
            List<DetalleVentas> attachedDetalleVentasListNew = new ArrayList<DetalleVentas>();
            for (DetalleVentas detalleVentasListNewDetalleVentasToAttach : detalleVentasListNew) {
                detalleVentasListNewDetalleVentasToAttach = em.getReference(detalleVentasListNewDetalleVentasToAttach.getClass(), detalleVentasListNewDetalleVentasToAttach.getIdDetalle());
                attachedDetalleVentasListNew.add(detalleVentasListNewDetalleVentasToAttach);
            }
            detalleVentasListNew = attachedDetalleVentasListNew;
            productos.setDetalleVentasList(detalleVentasListNew);
            List<DetalleCompras> attachedDetalleComprasListNew = new ArrayList<DetalleCompras>();
            for (DetalleCompras detalleComprasListNewDetalleComprasToAttach : detalleComprasListNew) {
                detalleComprasListNewDetalleComprasToAttach = em.getReference(detalleComprasListNewDetalleComprasToAttach.getClass(), detalleComprasListNewDetalleComprasToAttach.getIdDetalle());
                attachedDetalleComprasListNew.add(detalleComprasListNewDetalleComprasToAttach);
            }
            detalleComprasListNew = attachedDetalleComprasListNew;
            productos.setDetalleComprasList(detalleComprasListNew);
            productos = em.merge(productos);
            if (idProveedorOld != null && !idProveedorOld.equals(idProveedorNew)) {
                idProveedorOld.getProductosList().remove(productos);
                idProveedorOld = em.merge(idProveedorOld);
            }
            if (idProveedorNew != null && !idProveedorNew.equals(idProveedorOld)) {
                idProveedorNew.getProductosList().add(productos);
                idProveedorNew = em.merge(idProveedorNew);
            }
            for (AlmacenMovimientos almacenMovimientosListOldAlmacenMovimientos : almacenMovimientosListOld) {
                if (!almacenMovimientosListNew.contains(almacenMovimientosListOldAlmacenMovimientos)) {
                    almacenMovimientosListOldAlmacenMovimientos.setIdProducto(null);
                    almacenMovimientosListOldAlmacenMovimientos = em.merge(almacenMovimientosListOldAlmacenMovimientos);
                }
            }
            for (AlmacenMovimientos almacenMovimientosListNewAlmacenMovimientos : almacenMovimientosListNew) {
                if (!almacenMovimientosListOld.contains(almacenMovimientosListNewAlmacenMovimientos)) {
                    Productos oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos = almacenMovimientosListNewAlmacenMovimientos.getIdProducto();
                    almacenMovimientosListNewAlmacenMovimientos.setIdProducto(productos);
                    almacenMovimientosListNewAlmacenMovimientos = em.merge(almacenMovimientosListNewAlmacenMovimientos);
                    if (oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos != null && !oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos.equals(productos)) {
                        oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos.getAlmacenMovimientosList().remove(almacenMovimientosListNewAlmacenMovimientos);
                        oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos = em.merge(oldIdProductoOfAlmacenMovimientosListNewAlmacenMovimientos);
                    }
                }
            }
            for (DetalleVentas detalleVentasListOldDetalleVentas : detalleVentasListOld) {
                if (!detalleVentasListNew.contains(detalleVentasListOldDetalleVentas)) {
                    detalleVentasListOldDetalleVentas.setIdProducto(null);
                    detalleVentasListOldDetalleVentas = em.merge(detalleVentasListOldDetalleVentas);
                }
            }
            for (DetalleVentas detalleVentasListNewDetalleVentas : detalleVentasListNew) {
                if (!detalleVentasListOld.contains(detalleVentasListNewDetalleVentas)) {
                    Productos oldIdProductoOfDetalleVentasListNewDetalleVentas = detalleVentasListNewDetalleVentas.getIdProducto();
                    detalleVentasListNewDetalleVentas.setIdProducto(productos);
                    detalleVentasListNewDetalleVentas = em.merge(detalleVentasListNewDetalleVentas);
                    if (oldIdProductoOfDetalleVentasListNewDetalleVentas != null && !oldIdProductoOfDetalleVentasListNewDetalleVentas.equals(productos)) {
                        oldIdProductoOfDetalleVentasListNewDetalleVentas.getDetalleVentasList().remove(detalleVentasListNewDetalleVentas);
                        oldIdProductoOfDetalleVentasListNewDetalleVentas = em.merge(oldIdProductoOfDetalleVentasListNewDetalleVentas);
                    }
                }
            }
            for (DetalleCompras detalleComprasListOldDetalleCompras : detalleComprasListOld) {
                if (!detalleComprasListNew.contains(detalleComprasListOldDetalleCompras)) {
                    detalleComprasListOldDetalleCompras.setIdProducto(null);
                    detalleComprasListOldDetalleCompras = em.merge(detalleComprasListOldDetalleCompras);
                }
            }
            for (DetalleCompras detalleComprasListNewDetalleCompras : detalleComprasListNew) {
                if (!detalleComprasListOld.contains(detalleComprasListNewDetalleCompras)) {
                    Productos oldIdProductoOfDetalleComprasListNewDetalleCompras = detalleComprasListNewDetalleCompras.getIdProducto();
                    detalleComprasListNewDetalleCompras.setIdProducto(productos);
                    detalleComprasListNewDetalleCompras = em.merge(detalleComprasListNewDetalleCompras);
                    if (oldIdProductoOfDetalleComprasListNewDetalleCompras != null && !oldIdProductoOfDetalleComprasListNewDetalleCompras.equals(productos)) {
                        oldIdProductoOfDetalleComprasListNewDetalleCompras.getDetalleComprasList().remove(detalleComprasListNewDetalleCompras);
                        oldIdProductoOfDetalleComprasListNewDetalleCompras = em.merge(oldIdProductoOfDetalleComprasListNewDetalleCompras);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = productos.getIdProducto();
                if (findProductos(id) == null) {
                    throw new NonexistentEntityException("The productos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Productos productos;
            try {
                productos = em.getReference(Productos.class, id);
                productos.getIdProducto();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The productos with id " + id + " no longer exists.", enfe);
            }
            Proveedores idProveedor = productos.getIdProveedor();
            if (idProveedor != null) {
                idProveedor.getProductosList().remove(productos);
                idProveedor = em.merge(idProveedor);
            }
            List<AlmacenMovimientos> almacenMovimientosList = productos.getAlmacenMovimientosList();
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientos : almacenMovimientosList) {
                almacenMovimientosListAlmacenMovimientos.setIdProducto(null);
                almacenMovimientosListAlmacenMovimientos = em.merge(almacenMovimientosListAlmacenMovimientos);
            }
            List<DetalleVentas> detalleVentasList = productos.getDetalleVentasList();
            for (DetalleVentas detalleVentasListDetalleVentas : detalleVentasList) {
                detalleVentasListDetalleVentas.setIdProducto(null);
                detalleVentasListDetalleVentas = em.merge(detalleVentasListDetalleVentas);
            }
            List<DetalleCompras> detalleComprasList = productos.getDetalleComprasList();
            for (DetalleCompras detalleComprasListDetalleCompras : detalleComprasList) {
                detalleComprasListDetalleCompras.setIdProducto(null);
                detalleComprasListDetalleCompras = em.merge(detalleComprasListDetalleCompras);
            }
            em.remove(productos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Productos> findProductosEntities() {
        return findProductosEntities(true, -1, -1);
    }

    public List<Productos> findProductosEntities(int maxResults, int firstResult) {
        return findProductosEntities(false, maxResults, firstResult);
    }

    private List<Productos> findProductosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Productos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Productos findProductos(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Productos.class, id);
        } finally {
            em.close();
        }
    }

    public int getProductosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Productos> rt = cq.from(Productos.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

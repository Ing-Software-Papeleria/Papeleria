/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaController;

import JpaController.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;
import modelo.AlmacenMovimientos;
import modelo.Productos;
import modelo.Usuarios;

/**
 *
 * @author yisus
 */
public class AlmacenMovimientosJpaController implements Serializable {

    public AlmacenMovimientosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(AlmacenMovimientos almacenMovimientos) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Productos idProducto = almacenMovimientos.getIdProducto();
            if (idProducto != null) {
                idProducto = em.getReference(idProducto.getClass(), idProducto.getIdProducto());
                almacenMovimientos.setIdProducto(idProducto);
            }
            Usuarios idUsuario = almacenMovimientos.getIdUsuario();
            if (idUsuario != null) {
                idUsuario = em.getReference(idUsuario.getClass(), idUsuario.getIdUsuario());
                almacenMovimientos.setIdUsuario(idUsuario);
            }
            em.persist(almacenMovimientos);
            if (idProducto != null) {
                idProducto.getAlmacenMovimientosList().add(almacenMovimientos);
                idProducto = em.merge(idProducto);
            }
            if (idUsuario != null) {
                idUsuario.getAlmacenMovimientosList().add(almacenMovimientos);
                idUsuario = em.merge(idUsuario);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(AlmacenMovimientos almacenMovimientos) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AlmacenMovimientos persistentAlmacenMovimientos = em.find(AlmacenMovimientos.class, almacenMovimientos.getIdMovimiento());
            Productos idProductoOld = persistentAlmacenMovimientos.getIdProducto();
            Productos idProductoNew = almacenMovimientos.getIdProducto();
            Usuarios idUsuarioOld = persistentAlmacenMovimientos.getIdUsuario();
            Usuarios idUsuarioNew = almacenMovimientos.getIdUsuario();
            if (idProductoNew != null) {
                idProductoNew = em.getReference(idProductoNew.getClass(), idProductoNew.getIdProducto());
                almacenMovimientos.setIdProducto(idProductoNew);
            }
            if (idUsuarioNew != null) {
                idUsuarioNew = em.getReference(idUsuarioNew.getClass(), idUsuarioNew.getIdUsuario());
                almacenMovimientos.setIdUsuario(idUsuarioNew);
            }
            almacenMovimientos = em.merge(almacenMovimientos);
            if (idProductoOld != null && !idProductoOld.equals(idProductoNew)) {
                idProductoOld.getAlmacenMovimientosList().remove(almacenMovimientos);
                idProductoOld = em.merge(idProductoOld);
            }
            if (idProductoNew != null && !idProductoNew.equals(idProductoOld)) {
                idProductoNew.getAlmacenMovimientosList().add(almacenMovimientos);
                idProductoNew = em.merge(idProductoNew);
            }
            if (idUsuarioOld != null && !idUsuarioOld.equals(idUsuarioNew)) {
                idUsuarioOld.getAlmacenMovimientosList().remove(almacenMovimientos);
                idUsuarioOld = em.merge(idUsuarioOld);
            }
            if (idUsuarioNew != null && !idUsuarioNew.equals(idUsuarioOld)) {
                idUsuarioNew.getAlmacenMovimientosList().add(almacenMovimientos);
                idUsuarioNew = em.merge(idUsuarioNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = almacenMovimientos.getIdMovimiento();
                if (findAlmacenMovimientos(id) == null) {
                    throw new NonexistentEntityException("The almacenMovimientos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AlmacenMovimientos almacenMovimientos;
            try {
                almacenMovimientos = em.getReference(AlmacenMovimientos.class, id);
                almacenMovimientos.getIdMovimiento();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The almacenMovimientos with id " + id + " no longer exists.", enfe);
            }
            Productos idProducto = almacenMovimientos.getIdProducto();
            if (idProducto != null) {
                idProducto.getAlmacenMovimientosList().remove(almacenMovimientos);
                idProducto = em.merge(idProducto);
            }
            Usuarios idUsuario = almacenMovimientos.getIdUsuario();
            if (idUsuario != null) {
                idUsuario.getAlmacenMovimientosList().remove(almacenMovimientos);
                idUsuario = em.merge(idUsuario);
            }
            em.remove(almacenMovimientos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<AlmacenMovimientos> findAlmacenMovimientosEntities() {
        return findAlmacenMovimientosEntities(true, -1, -1);
    }

    public List<AlmacenMovimientos> findAlmacenMovimientosEntities(int maxResults, int firstResult) {
        return findAlmacenMovimientosEntities(false, maxResults, firstResult);
    }

    private List<AlmacenMovimientos> findAlmacenMovimientosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(AlmacenMovimientos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public AlmacenMovimientos findAlmacenMovimientos(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(AlmacenMovimientos.class, id);
        } finally {
            em.close();
        }
    }

    public int getAlmacenMovimientosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<AlmacenMovimientos> rt = cq.from(AlmacenMovimientos.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

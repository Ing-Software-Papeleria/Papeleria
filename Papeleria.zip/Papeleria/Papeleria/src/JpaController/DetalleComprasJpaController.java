/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaController;

import JpaController.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;
import modelo.Compras;
import modelo.DetalleCompras;
import modelo.Productos;

/**
 *
 * @author yisus
 */
public class DetalleComprasJpaController implements Serializable {

    public DetalleComprasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DetalleCompras detalleCompras) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Compras idCompra = detalleCompras.getIdCompra();
            if (idCompra != null) {
                idCompra = em.getReference(idCompra.getClass(), idCompra.getIdCompra());
                detalleCompras.setIdCompra(idCompra);
            }
            Productos idProducto = detalleCompras.getIdProducto();
            if (idProducto != null) {
                idProducto = em.getReference(idProducto.getClass(), idProducto.getIdProducto());
                detalleCompras.setIdProducto(idProducto);
            }
            em.persist(detalleCompras);
            if (idCompra != null) {
                idCompra.getDetalleComprasList().add(detalleCompras);
                idCompra = em.merge(idCompra);
            }
            if (idProducto != null) {
                idProducto.getDetalleComprasList().add(detalleCompras);
                idProducto = em.merge(idProducto);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DetalleCompras detalleCompras) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            DetalleCompras persistentDetalleCompras = em.find(DetalleCompras.class, detalleCompras.getIdDetalle());
            Compras idCompraOld = persistentDetalleCompras.getIdCompra();
            Compras idCompraNew = detalleCompras.getIdCompra();
            Productos idProductoOld = persistentDetalleCompras.getIdProducto();
            Productos idProductoNew = detalleCompras.getIdProducto();
            if (idCompraNew != null) {
                idCompraNew = em.getReference(idCompraNew.getClass(), idCompraNew.getIdCompra());
                detalleCompras.setIdCompra(idCompraNew);
            }
            if (idProductoNew != null) {
                idProductoNew = em.getReference(idProductoNew.getClass(), idProductoNew.getIdProducto());
                detalleCompras.setIdProducto(idProductoNew);
            }
            detalleCompras = em.merge(detalleCompras);
            if (idCompraOld != null && !idCompraOld.equals(idCompraNew)) {
                idCompraOld.getDetalleComprasList().remove(detalleCompras);
                idCompraOld = em.merge(idCompraOld);
            }
            if (idCompraNew != null && !idCompraNew.equals(idCompraOld)) {
                idCompraNew.getDetalleComprasList().add(detalleCompras);
                idCompraNew = em.merge(idCompraNew);
            }
            if (idProductoOld != null && !idProductoOld.equals(idProductoNew)) {
                idProductoOld.getDetalleComprasList().remove(detalleCompras);
                idProductoOld = em.merge(idProductoOld);
            }
            if (idProductoNew != null && !idProductoNew.equals(idProductoOld)) {
                idProductoNew.getDetalleComprasList().add(detalleCompras);
                idProductoNew = em.merge(idProductoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = detalleCompras.getIdDetalle();
                if (findDetalleCompras(id) == null) {
                    throw new NonexistentEntityException("The detalleCompras with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            DetalleCompras detalleCompras;
            try {
                detalleCompras = em.getReference(DetalleCompras.class, id);
                detalleCompras.getIdDetalle();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The detalleCompras with id " + id + " no longer exists.", enfe);
            }
            Compras idCompra = detalleCompras.getIdCompra();
            if (idCompra != null) {
                idCompra.getDetalleComprasList().remove(detalleCompras);
                idCompra = em.merge(idCompra);
            }
            Productos idProducto = detalleCompras.getIdProducto();
            if (idProducto != null) {
                idProducto.getDetalleComprasList().remove(detalleCompras);
                idProducto = em.merge(idProducto);
            }
            em.remove(detalleCompras);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DetalleCompras> findDetalleComprasEntities() {
        return findDetalleComprasEntities(true, -1, -1);
    }

    public List<DetalleCompras> findDetalleComprasEntities(int maxResults, int firstResult) {
        return findDetalleComprasEntities(false, maxResults, firstResult);
    }

    private List<DetalleCompras> findDetalleComprasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DetalleCompras.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DetalleCompras findDetalleCompras(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DetalleCompras.class, id);
        } finally {
            em.close();
        }
    }

    public int getDetalleComprasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DetalleCompras> rt = cq.from(DetalleCompras.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

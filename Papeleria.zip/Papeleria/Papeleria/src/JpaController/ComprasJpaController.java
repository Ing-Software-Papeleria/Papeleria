/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaController;

import JpaController.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Proveedores;
import modelo.DetalleCompras;
import java.util.ArrayList;
import java.util.List;
import modelo.Compras;

/**
 *
 * @author yisus
 */
public class ComprasJpaController implements Serializable {

    public ComprasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Compras compras) {
        if (compras.getDetalleComprasList() == null) {
            compras.setDetalleComprasList(new ArrayList<DetalleCompras>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Proveedores idProveedor = compras.getIdProveedor();
            if (idProveedor != null) {
                idProveedor = em.getReference(idProveedor.getClass(), idProveedor.getIdProveedor());
                compras.setIdProveedor(idProveedor);
            }
            List<DetalleCompras> attachedDetalleComprasList = new ArrayList<DetalleCompras>();
            for (DetalleCompras detalleComprasListDetalleComprasToAttach : compras.getDetalleComprasList()) {
                detalleComprasListDetalleComprasToAttach = em.getReference(detalleComprasListDetalleComprasToAttach.getClass(), detalleComprasListDetalleComprasToAttach.getIdDetalle());
                attachedDetalleComprasList.add(detalleComprasListDetalleComprasToAttach);
            }
            compras.setDetalleComprasList(attachedDetalleComprasList);
            em.persist(compras);
            if (idProveedor != null) {
                idProveedor.getComprasList().add(compras);
                idProveedor = em.merge(idProveedor);
            }
            for (DetalleCompras detalleComprasListDetalleCompras : compras.getDetalleComprasList()) {
                Compras oldIdCompraOfDetalleComprasListDetalleCompras = detalleComprasListDetalleCompras.getIdCompra();
                detalleComprasListDetalleCompras.setIdCompra(compras);
                detalleComprasListDetalleCompras = em.merge(detalleComprasListDetalleCompras);
                if (oldIdCompraOfDetalleComprasListDetalleCompras != null) {
                    oldIdCompraOfDetalleComprasListDetalleCompras.getDetalleComprasList().remove(detalleComprasListDetalleCompras);
                    oldIdCompraOfDetalleComprasListDetalleCompras = em.merge(oldIdCompraOfDetalleComprasListDetalleCompras);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Compras compras) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Compras persistentCompras = em.find(Compras.class, compras.getIdCompra());
            Proveedores idProveedorOld = persistentCompras.getIdProveedor();
            Proveedores idProveedorNew = compras.getIdProveedor();
            List<DetalleCompras> detalleComprasListOld = persistentCompras.getDetalleComprasList();
            List<DetalleCompras> detalleComprasListNew = compras.getDetalleComprasList();
            if (idProveedorNew != null) {
                idProveedorNew = em.getReference(idProveedorNew.getClass(), idProveedorNew.getIdProveedor());
                compras.setIdProveedor(idProveedorNew);
            }
            List<DetalleCompras> attachedDetalleComprasListNew = new ArrayList<DetalleCompras>();
            for (DetalleCompras detalleComprasListNewDetalleComprasToAttach : detalleComprasListNew) {
                detalleComprasListNewDetalleComprasToAttach = em.getReference(detalleComprasListNewDetalleComprasToAttach.getClass(), detalleComprasListNewDetalleComprasToAttach.getIdDetalle());
                attachedDetalleComprasListNew.add(detalleComprasListNewDetalleComprasToAttach);
            }
            detalleComprasListNew = attachedDetalleComprasListNew;
            compras.setDetalleComprasList(detalleComprasListNew);
            compras = em.merge(compras);
            if (idProveedorOld != null && !idProveedorOld.equals(idProveedorNew)) {
                idProveedorOld.getComprasList().remove(compras);
                idProveedorOld = em.merge(idProveedorOld);
            }
            if (idProveedorNew != null && !idProveedorNew.equals(idProveedorOld)) {
                idProveedorNew.getComprasList().add(compras);
                idProveedorNew = em.merge(idProveedorNew);
            }
            for (DetalleCompras detalleComprasListOldDetalleCompras : detalleComprasListOld) {
                if (!detalleComprasListNew.contains(detalleComprasListOldDetalleCompras)) {
                    detalleComprasListOldDetalleCompras.setIdCompra(null);
                    detalleComprasListOldDetalleCompras = em.merge(detalleComprasListOldDetalleCompras);
                }
            }
            for (DetalleCompras detalleComprasListNewDetalleCompras : detalleComprasListNew) {
                if (!detalleComprasListOld.contains(detalleComprasListNewDetalleCompras)) {
                    Compras oldIdCompraOfDetalleComprasListNewDetalleCompras = detalleComprasListNewDetalleCompras.getIdCompra();
                    detalleComprasListNewDetalleCompras.setIdCompra(compras);
                    detalleComprasListNewDetalleCompras = em.merge(detalleComprasListNewDetalleCompras);
                    if (oldIdCompraOfDetalleComprasListNewDetalleCompras != null && !oldIdCompraOfDetalleComprasListNewDetalleCompras.equals(compras)) {
                        oldIdCompraOfDetalleComprasListNewDetalleCompras.getDetalleComprasList().remove(detalleComprasListNewDetalleCompras);
                        oldIdCompraOfDetalleComprasListNewDetalleCompras = em.merge(oldIdCompraOfDetalleComprasListNewDetalleCompras);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = compras.getIdCompra();
                if (findCompras(id) == null) {
                    throw new NonexistentEntityException("The compras with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Compras compras;
            try {
                compras = em.getReference(Compras.class, id);
                compras.getIdCompra();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The compras with id " + id + " no longer exists.", enfe);
            }
            Proveedores idProveedor = compras.getIdProveedor();
            if (idProveedor != null) {
                idProveedor.getComprasList().remove(compras);
                idProveedor = em.merge(idProveedor);
            }
            List<DetalleCompras> detalleComprasList = compras.getDetalleComprasList();
            for (DetalleCompras detalleComprasListDetalleCompras : detalleComprasList) {
                detalleComprasListDetalleCompras.setIdCompra(null);
                detalleComprasListDetalleCompras = em.merge(detalleComprasListDetalleCompras);
            }
            em.remove(compras);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Compras> findComprasEntities() {
        return findComprasEntities(true, -1, -1);
    }

    public List<Compras> findComprasEntities(int maxResults, int firstResult) {
        return findComprasEntities(false, maxResults, firstResult);
    }

    private List<Compras> findComprasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Compras.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Compras findCompras(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Compras.class, id);
        } finally {
            em.close();
        }
    }

    public int getComprasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Compras> rt = cq.from(Compras.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaController;

import JpaController.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Roles;
import modelo.AlmacenMovimientos;
import java.util.ArrayList;
import java.util.List;
import modelo.Usuarios;

/**
 *
 * @author yisus
 */
public class UsuariosJpaController implements Serializable {

    public UsuariosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuarios usuarios) {
        if (usuarios.getAlmacenMovimientosList() == null) {
            usuarios.setAlmacenMovimientosList(new ArrayList<AlmacenMovimientos>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Roles idRol = usuarios.getIdRol();
            if (idRol != null) {
                idRol = em.getReference(idRol.getClass(), idRol.getIdRol());
                usuarios.setIdRol(idRol);
            }
            List<AlmacenMovimientos> attachedAlmacenMovimientosList = new ArrayList<AlmacenMovimientos>();
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientosToAttach : usuarios.getAlmacenMovimientosList()) {
                almacenMovimientosListAlmacenMovimientosToAttach = em.getReference(almacenMovimientosListAlmacenMovimientosToAttach.getClass(), almacenMovimientosListAlmacenMovimientosToAttach.getIdMovimiento());
                attachedAlmacenMovimientosList.add(almacenMovimientosListAlmacenMovimientosToAttach);
            }
            usuarios.setAlmacenMovimientosList(attachedAlmacenMovimientosList);
            em.persist(usuarios);
            if (idRol != null) {
                idRol.getUsuariosList().add(usuarios);
                idRol = em.merge(idRol);
            }
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientos : usuarios.getAlmacenMovimientosList()) {
                Usuarios oldIdUsuarioOfAlmacenMovimientosListAlmacenMovimientos = almacenMovimientosListAlmacenMovimientos.getIdUsuario();
                almacenMovimientosListAlmacenMovimientos.setIdUsuario(usuarios);
                almacenMovimientosListAlmacenMovimientos = em.merge(almacenMovimientosListAlmacenMovimientos);
                if (oldIdUsuarioOfAlmacenMovimientosListAlmacenMovimientos != null) {
                    oldIdUsuarioOfAlmacenMovimientosListAlmacenMovimientos.getAlmacenMovimientosList().remove(almacenMovimientosListAlmacenMovimientos);
                    oldIdUsuarioOfAlmacenMovimientosListAlmacenMovimientos = em.merge(oldIdUsuarioOfAlmacenMovimientosListAlmacenMovimientos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuarios usuarios) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios persistentUsuarios = em.find(Usuarios.class, usuarios.getIdUsuario());
            Roles idRolOld = persistentUsuarios.getIdRol();
            Roles idRolNew = usuarios.getIdRol();
            List<AlmacenMovimientos> almacenMovimientosListOld = persistentUsuarios.getAlmacenMovimientosList();
            List<AlmacenMovimientos> almacenMovimientosListNew = usuarios.getAlmacenMovimientosList();
            if (idRolNew != null) {
                idRolNew = em.getReference(idRolNew.getClass(), idRolNew.getIdRol());
                usuarios.setIdRol(idRolNew);
            }
            List<AlmacenMovimientos> attachedAlmacenMovimientosListNew = new ArrayList<AlmacenMovimientos>();
            for (AlmacenMovimientos almacenMovimientosListNewAlmacenMovimientosToAttach : almacenMovimientosListNew) {
                almacenMovimientosListNewAlmacenMovimientosToAttach = em.getReference(almacenMovimientosListNewAlmacenMovimientosToAttach.getClass(), almacenMovimientosListNewAlmacenMovimientosToAttach.getIdMovimiento());
                attachedAlmacenMovimientosListNew.add(almacenMovimientosListNewAlmacenMovimientosToAttach);
            }
            almacenMovimientosListNew = attachedAlmacenMovimientosListNew;
            usuarios.setAlmacenMovimientosList(almacenMovimientosListNew);
            usuarios = em.merge(usuarios);
            if (idRolOld != null && !idRolOld.equals(idRolNew)) {
                idRolOld.getUsuariosList().remove(usuarios);
                idRolOld = em.merge(idRolOld);
            }
            if (idRolNew != null && !idRolNew.equals(idRolOld)) {
                idRolNew.getUsuariosList().add(usuarios);
                idRolNew = em.merge(idRolNew);
            }
            for (AlmacenMovimientos almacenMovimientosListOldAlmacenMovimientos : almacenMovimientosListOld) {
                if (!almacenMovimientosListNew.contains(almacenMovimientosListOldAlmacenMovimientos)) {
                    almacenMovimientosListOldAlmacenMovimientos.setIdUsuario(null);
                    almacenMovimientosListOldAlmacenMovimientos = em.merge(almacenMovimientosListOldAlmacenMovimientos);
                }
            }
            for (AlmacenMovimientos almacenMovimientosListNewAlmacenMovimientos : almacenMovimientosListNew) {
                if (!almacenMovimientosListOld.contains(almacenMovimientosListNewAlmacenMovimientos)) {
                    Usuarios oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos = almacenMovimientosListNewAlmacenMovimientos.getIdUsuario();
                    almacenMovimientosListNewAlmacenMovimientos.setIdUsuario(usuarios);
                    almacenMovimientosListNewAlmacenMovimientos = em.merge(almacenMovimientosListNewAlmacenMovimientos);
                    if (oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos != null && !oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos.equals(usuarios)) {
                        oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos.getAlmacenMovimientosList().remove(almacenMovimientosListNewAlmacenMovimientos);
                        oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos = em.merge(oldIdUsuarioOfAlmacenMovimientosListNewAlmacenMovimientos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuarios.getIdUsuario();
                if (findUsuarios(id) == null) {
                    throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios usuarios;
            try {
                usuarios = em.getReference(Usuarios.class, id);
                usuarios.getIdUsuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.", enfe);
            }
            Roles idRol = usuarios.getIdRol();
            if (idRol != null) {
                idRol.getUsuariosList().remove(usuarios);
                idRol = em.merge(idRol);
            }
            List<AlmacenMovimientos> almacenMovimientosList = usuarios.getAlmacenMovimientosList();
            for (AlmacenMovimientos almacenMovimientosListAlmacenMovimientos : almacenMovimientosList) {
                almacenMovimientosListAlmacenMovimientos.setIdUsuario(null);
                almacenMovimientosListAlmacenMovimientos = em.merge(almacenMovimientosListAlmacenMovimientos);
            }
            em.remove(usuarios);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuarios> findUsuariosEntities() {
        return findUsuariosEntities(true, -1, -1);
    }

    public List<Usuarios> findUsuariosEntities(int maxResults, int firstResult) {
        return findUsuariosEntities(false, maxResults, firstResult);
    }

    private List<Usuarios> findUsuariosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuarios.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuarios findUsuarios(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuarios.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuariosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuarios> rt = cq.from(Usuarios.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

package util;

import modelo.Roles;

public class SesionActual {

    public static int idUsuario;
    public static String nombreUsuario;
    public static Roles rol;

}

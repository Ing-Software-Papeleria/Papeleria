package util;

import java.security.MessageDigest;

/**
 * Clase de utilidad para generar el hash de contraseñas (SHA-256).
 */
public class HashUtil {

    /**
     * Genera el hash SHA-256 de una contraseña.
     * @param password Contraseña original.
     * @return Cadena hexadecimal del hash.
     */
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error al generar el hash de la contraseña", e);
        }
    }

    // Método para pruebas (puedes ejecutarlo directamente)
    public static void main(String[] args) {
        String password = "admin123";
        String hash = hashPassword(password);
        System.out.println("Contraseña: " + password);
        System.out.println("Hash SHA-256: " + hash);
    }
}

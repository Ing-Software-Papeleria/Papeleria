package util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import org.mindrot.jbcrypt.BCrypt;

/**
 * Clase que lee varias contraseñas desde un archivo .txt, 
 * las hashea con BCrypt y guarda los hashes resultantes 
 * en otro archivo de texto.
 */
public class BCryptFileHasher {

    /**
     * Hashea una contraseña usando BCrypt.
     */
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    /**
     * Lee todas las contraseñas de un archivo.
     * Cada línea se considera una contraseña.
     */
    public static List<String> readPasswordsFromFile(String inputPath) throws IOException {
        List<String> passwords = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) { // evita líneas vacías
                    passwords.add(line.trim());
                }
            }
        }
        return passwords;
    }

    /**
     * Escribe todos los hashes en un archivo.
     * Cada hash se guarda en una nueva línea.
     */
    public static void writeHashesToFile(List<String> hashes, String outputPath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            for (String hash : hashes) {
                writer.write(hash);
                writer.newLine();
            }
        }
    }

    /**
     * Programa principal:
     * Lee contraseñas desde "passwords.txt" y genera "hashed_passwords.txt".
     */
    public static void main(String[] args) {
        String inputFile = "C:\\Users\\yisus\\Documents\\passwords.txt";
        String outputFile = "C:\\Users\\yisus\\Documents\\hashed_passwords.txt";


        try {
            // Leer contraseñas
            List<String> passwords = readPasswordsFromFile(inputFile);
            List<String> hashedList = new ArrayList<>();

            // Hashear cada una
            for (String pwd : passwords) {
                String hash = hashPassword(pwd);
                hashedList.add(hash);
                System.out.println("Contraseña: " + pwd + " → Hash generado");
            }

            // Guardar resultados
            writeHashesToFile(hashedList, outputFile);
            System.out.println("\n✅ Hashes generados y guardados en: " + outputFile);

        } catch (IOException e) {
            System.err.println("❌ Error al procesar los archivos: " + e.getMessage());
        }
    }
}

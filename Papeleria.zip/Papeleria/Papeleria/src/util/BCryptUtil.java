package util;

import org.mindrot.jbcrypt.BCrypt;

public class BCryptUtil {

    // Genera un hash seguro (solo cuando el usuario se registra o cambia contraseña)
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    // Verifica una contraseña ingresada contra su hash guardado
    public static boolean checkPassword(String plainPassword, String hashedPassword) {

        if (hashedPassword == null) {
            return false;
        }

        // Si NO es un hash BCrypt (no empieza con $2), comparar como texto normal
        if (!hashedPassword.startsWith("$2")) {
            return plainPassword.equals(hashedPassword);
        }

        // Si es un hash BCrypt, validar con BCrypt
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.ProductoDAO;
import modelo.Productos; // Asegúrate de que tu clase modelo se llame 'Productos' (con S) como en tu DAO
import java.util.List;
import java.math.BigDecimal;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductoDAOTest {

    ProductoDAO dao = new ProductoDAO();

    @Test
    public void testInsertarProducto() {
        // Tu DAO pide los datos separados, no un objeto completo.
        // Además requiere BigDecimal para el precio.
        String nombre = "Producto JUnit " + (int)(Math.random() * 1000);
        BigDecimal precio = new BigDecimal("15.50");
        
        // dao.insertarProducto devuelve el ID generado (int)
        int idGenerado = dao.insertarProducto(nombre, "Categoría Prueba", precio, 10, 5);
        
        // Si el ID es mayor a 0, se insertó correctamente
        assertTrue("El ID del producto debería ser mayor a 0", idGenerado > 0);
    }

    @Test
    public void testInsertarProductoInvalido() {
        // Probamos enviando null para forzar un error
        // Tu DAO captura la excepción y devuelve -1
        int idGenerado = dao.insertarProducto(null, null, null, 0, 0);
        
        assertEquals("El registro debería fallar y devolver -1", -1, idGenerado);
    }

    @Test
    public void testBuscarProducto() {
        // Usamos el método correcto: buscarProducto (no buscarPorId)
        // Asegúrate de tener un producto con ID 1 en tu BD
        Productos p = dao.buscarProducto(1);
        
        assertNotNull("El producto con ID 1 debería existir", p);
        
        if(p != null) {
            System.out.println("Producto encontrado: " + p.getNombre());
        }
    }

    @Test
    public void testBuscarProductoInexistente() {
        Productos p = dao.buscarProducto(999999);
        assertNull("El producto no debería existir", p);
    }

    @Test
    public void testObtenerProductos() {
        // Tu DAO devuelve List<Object[]>, no List<Productos>
        // Y el método se llama obtenerProductos, no listarTodos
        List<Object[]> lista = dao.obtenerProductos();
        
        assertNotNull(lista);
        
        if (!lista.isEmpty()) {
            assertTrue(lista.get(0) instanceof Object[]);
            // Imprimimos el nombre del primer producto (posición 0 del array)
            System.out.println("Primer producto en lista: " + lista.get(0)[0]);
        }
    }

    @Test
    public void testActualizarStock() {
        // 1. Insertamos un producto dummy para probar
        BigDecimal precio = new BigDecimal("10.0");
        int id = dao.insertarProducto("Test Stock", "Test", precio, 100, 5);
        
        if (id > 0) {
            // 2. Restamos 10 al stock
            dao.actualizarStock(id, 10);
            
            // 3. Verificamos buscando el producto de nuevo
            Productos p = dao.buscarProducto(id);
            
            // CORRECCIÓN AQUÍ: Agregamos 'L' al 90 y (long) al resultado para evitar ambigüedad
            assertEquals("El stock debería haber bajado a 90", 90L, (long)p.getStockActual());
        }
    }

    // -----------------------------------------------------------------------
    // MÉTODOS COMENTADOS (No existen en tu DAO actual)
    // -----------------------------------------------------------------------
    
    /*
    @Test
    public void testEliminarProducto() {
        // Tu ProductoDAO NO tiene método eliminar.
        // Debes crearlo en el DAO si quieres probarlo.
    }
    
    @Test
    public void testActualizarProductoCompleto() {
        // Tu ProductoDAO NO tiene método para actualizar nombre, precio, etc.
        // Solo tiene actualizarStock.
    }
    */
}
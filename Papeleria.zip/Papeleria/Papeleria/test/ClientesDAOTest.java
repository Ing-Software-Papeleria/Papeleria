/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.ClientesDAO;
import modelo.Clientes;
import java.util.List;
// 1. CAMBIAMOS LOS IMPORTS A JUNIT 4
import org.junit.Test;
import static org.junit.Assert.*;

public class ClientesDAOTest {
    
    ClientesDAO dao = new ClientesDAO();

    @Test
    public void testRegistrarCliente() {
        Clientes c = new Clientes(); 
        c.setNombre("Prueba JUnit");
        c.setTelefono("9999999999");
        c.setEmail("email@junit.com");
        
        int idGenerado = dao.registrarCliente(c);
        
        // JUNIT 4: El mensaje va PRIMERO
        assertTrue("El ID generado debería ser mayor a 0", idGenerado > 0);
    }

    @Test
    public void testRegistrarClienteInvalido() {
        Clientes c = new Clientes();
        c.setNombre(null); 
        c.setTelefono(null);
        c.setEmail(null);
        
        int idGenerado = dao.registrarCliente(c);
        
        // JUNIT 4: (Mensaje, Esperado, Actual)
        assertEquals("El registro debería fallar y devolver -1", -1, idGenerado);
    }

    @Test
    public void testBuscarCliente() {
        // Asegúrate que el ID 1 exista
        Clientes c = dao.buscarCliente(1);
        
        assertNotNull("El cliente con ID 1 debería existir", c);
    }

    @Test
    public void testBuscarClienteInexistente() {
        Clientes c = dao.buscarCliente(999999);
        
        assertNull("El cliente no debería existir", c);
    }

    @Test
    public void testListarClientes() {
        List<Object[]> lista = dao.obtenerClientes();
        
        assertNotNull("La lista no debe ser nula", lista);
        
        if (!lista.isEmpty()) {
            // Validamos que sea un array de objetos
            assertTrue("Debería ser una instancia de Object[]", lista.get(0) instanceof Object[]);
            
            Object[] primerCliente = lista.get(0);
            System.out.println("Cliente encontrado: " + primerCliente[1]); 
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.DetalleVentasDAO;
import java.math.BigDecimal;
import org.junit.Test;
import static org.junit.Assert.*;

public class DetalleVentasDAOTest {

    DetalleVentasDAO dao = new DetalleVentasDAO();

    @Test
    public void testRegistrarDetalle() {
        // DATOS DE PRUEBA:
        // Necesitas que existan la Venta ID 1 y el Producto ID 1 en tu BD.
        // Si no existen, cambia estos números por unos reales.
        int idVenta = 1;
        int idProducto = 1;
        int cantidad = 3;
        BigDecimal precio = new BigDecimal("50.00");
        
        try {
            // Ejecutamos el método. Como devuelve void, no podemos hacer assertTrue(resultado).
            // Si hay un error SQL, tu DAO imprimirá el error en la consola (letras rojas).
            dao.registrarDetalle(idVenta, idProducto, cantidad, precio);
            
            // Si llega a esta línea sin que el programa colapse, consideramos que pasó.
            assertTrue(true);
            
        } catch (Exception e) {
            fail("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // MÉTODOS COMENTADOS (No se pueden probar con tu DAO actual)
    // -------------------------------------------------------------------------
    
    /*
    @Test
    public void testInsertarDetalleCantidadInvalida() {
        // Tu DAO no tiene validación para negativos, así que la base de datos lo aceptará
        // o lanzará un error que tu DAO capturará, por lo que este test no sirve mucho ahorita.
    }

    @Test
    public void testListarDetalles() {
        // Tu DAO NO tiene el método listarPorVenta.
        // Tienes que crearlo en el DAO para poder probarlo.
    }
    */
    
    // Método MAIN por si NetBeans no quiere correrlo como Test File
    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("DetalleVentasDAOTest");
    }
}
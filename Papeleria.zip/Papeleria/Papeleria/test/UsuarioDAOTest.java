/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.UsuarioDAO;
import modelo.Usuarios;
// Importaciones correctas para JUnit 4 (NetBeans)
import org.junit.Test;
import static org.junit.Assert.*;

public class UsuarioDAOTest {

    UsuarioDAO dao = new UsuarioDAO();

    @Test
    public void testObtenerPorCodigoExistente() {
        // Tu DAO solo busca por "codigo_usuario". 
        // Asumimos que tienes un usuario con código "admin" en tu BD.
        Usuarios u = dao.obtenerPorCodigo("USR002");
        
        assertNotNull("El usuario con código 'USR002' debería existir", u);
        
        if (u != null) {
            System.out.println("Usuario encontrado: " + u.getNombreUsuario());
        }
    }

    @Test
    public void testObtenerPorCodigoInexistente() {
        // Probamos un código que seguro no existe
        Usuarios u = dao.obtenerPorCodigo("CODIGO_INVENTADO_999");
        
        assertNull("El usuario no debería existir", u);
    }

    @Test
    public void testValidarContrasenaManual() {
        // Como tu DAO NO tiene el método 'validarUsuario', 
        // simulamos el login trayendo el usuario y comparando la contraseña aquí.
        
        Usuarios u = dao.obtenerPorCodigo("USR002");
        
        // 1. Verificamos que el usuario exista
        assertNotNull("No se puede probar login si el usuario 'USR002' no existe", u);
        
        // 2. Verificamos que la contraseña sea la esperada (ej. "1234")
        // IMPORTANTE: Asegúrate que en tu BD la contraseña sea "1234"
        assertEquals("La contraseña debería coincidir", "123456", u.getContrasena());
    }

    // -------------------------------------------------------------------------
    // MÉTODOS COMENTADOS (No existen en tu UsuarioDAO actual)
    // -------------------------------------------------------------------------

    /*
    @Test
    public void testBuscarUsuarioPorId() {
        // Tu DAO no tiene método buscarPorId, solo por Código.
        // Si lo agregas al DAO, descomenta esto:
        // Usuarios u = dao.buscarUsuarioPorId(1);
        // assertNotNull(u);
    }
    
    @Test
    public void testBuscarUsuarioPorNombre() {
        // Tu DAO no tiene método buscarPorNombre.
    }
    */
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.ReporteDAO;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class ReporteDAOTest {

    ReporteDAO dao = new ReporteDAO();

    @Test
    public void testVentasDelMes() {
        // Método estático
        double ventas = ReporteDAO.obtenerVentasDelMes();
        
        // Solo validamos que no dé error y sea un número válido
        System.out.println("Ventas del mes: " + ventas);
        assertTrue("Las ventas no pueden ser negativas", ventas >= 0);
    }

    @Test
    public void testObtenerStockFinal() {
        // Método de instancia
        int stock = dao.obtenerStockFinal();
        
        System.out.println("Stock total en inventario: " + stock);
        assertTrue("El stock total debe ser mayor o igual a 0", stock >= 0);
    }
    
    @Test
    public void testObtenerValorInventario() {
        // Verifica el cálculo de dinero invertido
        double valor = dao.obtenerValorInventario();
        
        System.out.println("Valor del inventario: $" + valor);
        assertTrue("El valor del inventario debe ser >= 0", valor >= 0);
    }

    @Test
    public void testTopProductos() {
        // Verifica el ranking de productos más vendidos
        List<Object[]> top = dao.obtenerTopProductos();
        
        assertNotNull(top);
        // No forzamos !isEmpty() porque si no hay ventas, la lista estará vacía, lo cual es correcto.
        if (!top.isEmpty()) {
            System.out.println("Producto Top 1: " + top.get(0)[0]);
            assertEquals("Cada fila debe tener 3 columnas (Nombre, Cantidad, Dinero)", 3, top.get(0).length);
        }
    }
    
    @Test
    public void testClientesNuevos() {
        int nuevos = ReporteDAO.obtenerClientesNuevos();
        assertTrue("Clientes nuevos debe ser >= 0", nuevos >= 0);
    }

    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("ReporteDAOTest");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.AlmacenDAO;
import dao.ReporteAlmacenDAO;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class AlmacenDAOTest {

    AlmacenDAO dao = new AlmacenDAO();

    @Test
    public void testRegistrarEntrada() {
        // Simula una entrada de mercancía
        // Requiere: Producto ID 1 y Usuario ID 1 existentes
        int idProducto = 1;
        int cantidad = 5;
        int idUsuario = 152; 
        
        boolean resultado = dao.registrarMovimiento(idProducto, "entrada", cantidad, idUsuario);
        
        assertTrue("La entrada de almacén debería registrarse correctamente", resultado);
    }

    @Test
    public void testRegistrarSalida() {
        // Simula una salida (venta o retiro)
        // Requiere: Producto ID 1 y Usuario ID 1 existentes
        int idProducto = 1;
        int cantidad = 1; 
        int idUsuario = 152;
        
        boolean resultado = dao.registrarMovimiento(idProducto, "salida", cantidad, idUsuario);
        
        assertTrue("La salida de almacén debería registrarse correctamente", resultado);
    }

    @Test
    public void testObtenerMovimientosHoy() {
        List<Object[]> lista = dao.obtenerMovimientosHoy();
        
        assertNotNull("La lista de movimientos no debe ser nula", lista);
        
        if (!lista.isEmpty()) {
            Object[] mov = lista.get(0);
            System.out.println("Movimiento detectado: " + mov[1] + " - Tipo: " + mov[2]);
            // Verificamos que traiga datos (Hora, Producto, Tipo, Cantidad...)
            assertEquals("Debe tener 6 columnas", 6, mov.length);
        }
    }
    
    // --- Pruebas de ReporteAlmacenDAO (Métricas de Almacén) ---
    
    @Test
    public void testReporteProductosRecibidos() {
        // Método estático de ReporteAlmacenDAO
        int total = ReporteAlmacenDAO.obtenerProductosRecibidosHoy();
        assertTrue("El total de productos recibidos debe ser >= 0", total >= 0);
    }
    
    @Test
    public void testReporteStockAgregado() {
        int total = ReporteAlmacenDAO.obtenerStockAgregadoHoy();
        assertTrue("El stock agregado debe ser >= 0", total >= 0);
    }

    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("AlmacenDAOTest");
    }
}
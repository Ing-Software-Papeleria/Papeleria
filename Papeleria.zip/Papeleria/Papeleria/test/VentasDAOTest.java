/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.VentasDAO;
// import modelo.Ventas; // No lo usamos porque el DAO pide parametros sueltos
import java.util.List;
import java.math.BigDecimal; // Importante para manejar precios
import org.junit.Test;
import static org.junit.Assert.*;

public class VentasDAOTest {

    VentasDAO dao = new VentasDAO();

    @Test
    public void testRegistrarVenta() {
        // Tu DAO requiere: idCliente (int), total (BigDecimal), estado (String)
        BigDecimal total = new BigDecimal("200.50");
        
        // Asumimos que el cliente con ID 1 existe. Si no, cambia el 1 por un ID real.
        int idGenerado = dao.registrarVenta(1, total, "Completado");
        
        // Si sale bien, devuelve el ID generado (> 0)
        assertTrue("El ID de la venta debería ser mayor a 0", idGenerado > 0);
    }

    @Test
    public void testRegistrarVentaConClienteInexistente() {
        BigDecimal total = new BigDecimal("100.00");
        
        // Intentamos registrar con un cliente 999999 que no existe
        // Tu base de datos debería lanzar error de llave foránea (Foreign Key)
        // Y tu DAO captura el error y devuelve -1
        int idGenerado = dao.registrarVenta(999999, total, "Pendiente");
        
        assertEquals("El registro debería fallar por cliente inexistente", -1, idGenerado);
    }

    @Test
    public void testObtenerVentas() {
        // Tu DAO devuelve una lista de Arreglos de Objetos
        List<Object[]> lista = dao.obtenerVentas();
        
        assertNotNull("La lista no debe ser nula", lista);
        
        if (!lista.isEmpty()) {
            assertTrue(lista.get(0) instanceof Object[]);
            // Imprimimos para verificar en consola
            System.out.println("Venta ID: " + lista.get(0)[0] + " - Cliente: " + lista.get(0)[3]);
        }
    }
    
    @Test
    public void testObtenerVentasDeHoy() {
        // Probamos el método específico que filtra por fecha actual
        List<Object[]> lista = dao.obtenerVentasDeHoy();
        assertNotNull(lista);
        // No forzamos que size > 0 porque quizás hoy no has vendido nada,
        // pero verificamos que no sea null.
    }

    // -------------------------------------------------------------------------
    // MÉTODOS COMENTADOS (No existen en tu VentasDAO actual)
    // -------------------------------------------------------------------------
    
    /*
    @Test
    public void testBuscarVenta() {
        // Tu DAO no tiene método buscarPorId para ventas.
        // Ventas v = dao.buscarPorId(1);
    }

    @Test
    public void testBuscarVentaInexistente() {
        // Tu DAO no tiene método buscarPorId para ventas.
    }
    */
}
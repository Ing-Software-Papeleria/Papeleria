/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adair
 */
import dao.ProveedorDAO;
import modelo.Proveedores;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProveedorDAOTest {

    ProveedorDAO dao = new ProveedorDAO();

    @Test
    public void testInsertarProveedor() {
        // Usamos un aleatorio para evitar error de duplicados si corres el test varias veces
        String nombre = "Prov. Test " + (int)(Math.random() * 1000);
        
        boolean resultado = dao.insertarProveedor(nombre, "555-0000", "test@proveedor.com");
        
        assertTrue("El proveedor debería insertarse correctamente", resultado);
    }

    @Test
    public void testObtenerProveedores() {
        List<Proveedores> lista = dao.obtenerProveedores();
        
        assertNotNull("La lista de proveedores no debe ser nula", lista);
        
        if (!lista.isEmpty()) {
            System.out.println("Proveedor encontrado: " + lista.get(0).getNombre());
        }
    }

    @Test
    public void testBuscarProveedorExistente() {
        // Primero insertamos uno para asegurar que existe
        String nombreUnico = "Buscable " + System.currentTimeMillis();
        dao.insertarProveedor(nombreUnico, "111", "buscar@me.com");
        
        List<Proveedores> lista = dao.buscarProveedores(nombreUnico);
        
        assertNotNull(lista);
        assertFalse("Debería encontrar al menos un proveedor", lista.isEmpty());
        assertEquals(nombreUnico, lista.get(0).getNombre());
    }

    @Test
    public void testBuscarProveedorInexistente() {
        List<Proveedores> lista = dao.buscarProveedores("XYZ_NO_EXISTE_123");
        
        assertNotNull(lista);
        assertTrue("La lista debería estar vacía", lista.isEmpty());
    }

    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("ProveedorDAOTest");
    }
}
